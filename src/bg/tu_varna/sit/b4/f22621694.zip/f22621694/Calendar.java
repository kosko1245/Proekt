package bg.tu_varna.sit.b4.f22621694;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Calendar implements Serializable {
    public static final LocalTime START_TIME = LocalTime.of(8, 00);
    public static final LocalTime END_TIME = LocalTime.of(17, 1);
    private List<Event> events = new ArrayList<>();
    private String currentFile;
    private ObjectInputStream fStream=null;

   /* public void open(String filePath) throws CalendarException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            fStream=ois;
            events = (List<Event>) ois.readObject();
            currentFile = filePath;
            System.out.println("Successfully opened " + filePath);
        } catch (IOException | ClassNotFoundException e) {
            throw new CalendarException("Error opening file: " + e.getMessage());
        }
    }*/

    // Method to open a calendar file, creating a new file if not found
    public void open(String filePath) throws CalendarException {
        File file = new File(filePath);
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File not found. Created new file: " + filePath);
                    events = new ArrayList<>();
                    saveAs(filePath);
                } else {
                    throw new CalendarException("Failed to create new file: " + filePath);
                }
            } catch (IOException e) {
                throw new CalendarException("Error creating new file: " + e.getMessage());
            }
        } else {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
                events = (List<Event>) ois.readObject();
                currentFile = filePath;
                System.out.println("Successfully opened " + filePath);
            } catch (IOException | ClassNotFoundException e) {
                throw new CalendarException("Error opening file: " + e.getMessage());
            }
        }
    }
    public void close() throws CalendarException, IOException {
        if (currentFile == null) {
            throw new CalendarException("No file is currently open.");
        }
        events.clear();
        if(fStream!=null) fStream.close();
        currentFile = null;
        System.out.println("Successfully closed the file.");
    }

    public void save() throws CalendarException {
        if (currentFile == null) {
            throw new CalendarException("No file is currently open.");
        }
        saveAs(currentFile);
    }

    public void saveAs(String filePath) throws CalendarException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(events);
            currentFile = filePath;
            System.out.println("Successfully saved " + filePath);
        } catch (IOException e) {
            throw new CalendarException("Error saving file: " + e.getMessage());
        }
    }

    public void book(String dateStr, String startTimeStr, String endTimeStr, String name, String note) throws CalendarException {
        LocalDate date = LocalDate.parse(dateStr);
        LocalTime startTime = LocalTime.parse(startTimeStr);
        LocalTime endTime = LocalTime.parse(endTimeStr);

        Event event = new Event(date, startTime, endTime, name, note);
        if (events.stream().anyMatch(e -> e.conflictsWith(event))) {
            throw new CalendarException("Conflicting event exists for the given time.");
        }
        events.add(event);
        System.out.println("Successfully booked: " + event);
    }

    public void unbook(String dateStr, String startTimeStr, String endTimeStr) throws CalendarException {
        LocalDate date = LocalDate.parse(dateStr);
        LocalTime startTime = LocalTime.parse(startTimeStr);
        LocalTime endTime = LocalTime.parse(endTimeStr);

        boolean removed = events.removeIf(event -> event.getDate().equals(date) && event.getStartTime().equals(startTime) && event.getEndTime().equals(endTime));
        if (!removed) {
            throw new CalendarException("No event found for the given date and time.");
        }
        System.out.println("Successfully canceled the event on " + date + " from " + startTime + " to " + endTime);
    }

    public void agenda(String dateStr) throws CalendarException {
        LocalDate date = LocalDate.parse(dateStr);
        List<Event> dailyEvents = events.stream()
                .filter(event -> event.getDate().equals(date))
                .collect(Collectors.toList());

        if (dailyEvents.isEmpty()) {
            throw new CalendarException("No events found for " + date);
        } else {
            dailyEvents.forEach(System.out::println);
        }
    }

    public void change(String dateStr, String startTimeStr, String option, String newValue) throws CalendarException {
        LocalDate date = LocalDate.parse(dateStr);
        LocalTime startTime = LocalTime.parse(startTimeStr);

        for (Event event : events) {
            if (event.getDate().equals(date) && event.getStartTime().equals(startTime)) {
                switch (option) {
                    case "date":
                        event.setDate(LocalDate.parse(newValue));
                        break;
                    case "starttime":
                        event.setStartTime(LocalTime.parse(newValue));
                        break;
                    case "endtime":
                        event.setEndTime(LocalTime.parse(newValue));
                        break;
                    case "name":
                        event.setName(newValue);
                        break;
                    case "note":
                        event.setNote(newValue);
                        break;
                    default:
                        throw new CalendarException("Invalid option. Valid options are: date, starttime, endtime, name, note.");
                }
                System.out.println("Successfully changed the event: " + event);
                return;
            }
        }
        throw new CalendarException("Event not found.");
    }

    public void find(String searchString) throws CalendarException {
        List<Event> foundEvents = events.stream()
                .filter(event -> event.getName().contains(searchString) || event.getNote().contains(searchString))
                .collect(Collectors.toList());

        if (foundEvents.isEmpty()) {
            throw new CalendarException("No events found containing: " + searchString);
        } else {
            foundEvents.forEach(System.out::println);
        }
    }

    public void holiday(String dateStr) throws CalendarException {
        LocalDate date = LocalDate.parse(dateStr);
        events.add(new Event(date, LocalTime.MIN, LocalTime.MAX, "Holiday", ""));
        System.out.println("Successfully marked " + date + " as a holiday.");
    }

    public void busyDays(String fromDateStr, String toDateStr) throws CalendarException {
        LocalDate fromDate = LocalDate.parse(fromDateStr);
        LocalDate toDate = LocalDate.parse(toDateStr);

        List<Event> periodEvents = events.stream()
                .filter(event -> !event.getDate().isBefore(fromDate) && !event.getDate().isAfter(toDate))
                .collect(Collectors.toList());

        if (periodEvents.isEmpty()) {
            throw new CalendarException("No events found in the given period.");
        } else {
            periodEvents.stream()
                    .collect(Collectors.groupingBy(Event::getDate))
                    .entrySet().stream()
                    .sorted((e1, e2) -> e2.getValue().size() - e1.getValue().size())
                    .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue().size() + " events"));
        }
    }

    public void findSlot(String fromDateStr, int hours) throws CalendarException {
        LocalDate fromDate = LocalDate.parse(fromDateStr);
        LocalTime startTime = START_TIME;
        LocalTime endTime = END_TIME;

        // Duration of the slot in minutes
        int slotDurationMinutes = hours * 60;

        for (LocalDate date = fromDate; date.isBefore(fromDate.plusMonths(1)); date = date.plusDays(1)) {
            LocalDate finalDate = date;

            // Filter events for the current date
            List<Event> eventsForDate = events.stream()
                    .filter(event -> event.getDate().equals(finalDate))
                    .sorted(Comparator.comparing(Event::getStartTime))
                    .collect(Collectors.toList());

            // Check if there is a slot before the first event
            if (eventsForDate.isEmpty() || eventsForDate.get(0).getStartTime().isAfter(startTime.plusMinutes(slotDurationMinutes))) {
                System.out.println("Found slot on " + finalDate + " from " + startTime + " to " + startTime.plusMinutes(slotDurationMinutes));
                return;
            }

            // Check between events
            for (int i = 0; i < eventsForDate.size() - 1; i++) {
                LocalTime endOfCurrentEvent = eventsForDate.get(i).getEndTime();
                LocalTime startOfNextEvent = eventsForDate.get(i + 1).getStartTime();

                if (endOfCurrentEvent.plusMinutes(slotDurationMinutes).isBefore(startOfNextEvent)) {
                    System.out.println("Found slot on " + finalDate + " from " + endOfCurrentEvent + " to " + endOfCurrentEvent.plusMinutes(slotDurationMinutes));
                    return;
                }
            }

            // Check if there is a slot after the last event
            LocalTime endOfLastEvent = eventsForDate.get(eventsForDate.size() - 1).getEndTime();
            if (endOfLastEvent.plusMinutes(slotDurationMinutes).isBefore(endTime)) {
                System.out.println("Found slot on " + finalDate + " from " + endOfLastEvent + " to " + endOfLastEvent.plusMinutes(slotDurationMinutes));
                return;
            }

            // Check for an entirely free day
            if (eventsForDate.isEmpty()) {
                System.out.println("Found slot on " + finalDate + " from " + startTime + " to " + startTime.plusMinutes(slotDurationMinutes));
                return;
            }
        }

        // No slot found within the next month
        throw new CalendarException("No available slot found from " + fromDate + " for " + hours + " hours.");
    }

    public void findSlotWith(String fromDateStr, int hours, String calendarFile) throws CalendarException {
        Calendar externalCalendar = new Calendar();
        externalCalendar.open(calendarFile);

        LocalDate fromDate = LocalDate.parse(fromDateStr);
        LocalTime startTime = START_TIME;
        LocalTime endTime = END_TIME;

        // Duration of the slot in minutes
        int slotDurationMinutes = hours * 60;

        for (LocalDate date = fromDate; !date.isAfter(fromDate.plusMonths(1).minusDays(1)); date = date.plusDays(1)) {
            LocalDate finalDate = date;

            // Get events for the current and external calendars for the current date
            List<Event> currentEvents = events.stream()
                    .filter(event -> event.getDate().equals(finalDate))
                    .sorted(Comparator.comparing(Event::getStartTime))
                    .collect(Collectors.toList());

            List<Event> externalEvents = externalCalendar.events.stream()
                    .filter(event -> event.getDate().equals(finalDate))
                    .sorted(Comparator.comparing(Event::getStartTime))
                    .collect(Collectors.toList());

            // Check for available slots within the specified time window (8 AM to 5 PM)
            LocalTime currentTime = START_TIME;
            while (currentTime.plusMinutes(slotDurationMinutes).isBefore(END_TIME)) {
                final LocalTime slotStart = currentTime;
                final LocalTime slotEnd = currentTime.plusMinutes(slotDurationMinutes);

                boolean slotAvailable = currentEvents.stream().noneMatch(event ->
                        (event.getStartTime().isBefore(slotEnd) && event.getEndTime().isAfter(slotStart))
                ) && externalEvents.stream().noneMatch(event ->
                        (event.getStartTime().isBefore(slotEnd) && event.getEndTime().isAfter(slotStart))
                );

                if (slotAvailable) {
                    System.out.println("Found slot on " + finalDate + " from " + slotStart + " to " + slotEnd);
                    return;
                }

                currentTime = currentTime.plusMinutes(30); // Move to the next potential slot
            }
        }

        // No slot found within the next month
        throw new CalendarException("No available slot found from " + fromDate + " for " + hours + " hours.");
    }


    public void merge(String calendarFile) throws CalendarException {
        Calendar externalCalendar = new Calendar();
        externalCalendar.open(calendarFile);

        for (Event externalEvent : externalCalendar.events) {
            if (events.stream().noneMatch(event -> event.conflictsWith(externalEvent))) {
                events.add(externalEvent);
                System.out.println("Merged event: " + externalEvent);
            } else {
                System.out.println("Conflict with event: " + externalEvent);
            }
        }
    }
}
