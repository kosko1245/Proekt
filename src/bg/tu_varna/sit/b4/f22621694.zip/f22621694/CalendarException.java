package bg.tu_varna.sit.b4.f22621694;

public class CalendarException extends Exception {
    public CalendarException(String message) {
        super(message);
    }
}

