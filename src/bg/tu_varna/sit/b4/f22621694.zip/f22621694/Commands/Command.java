package bg.tu_varna.sit.b4.f22621694.Commands;
public interface Command {
    void execute(String[] args);
    String getUsage();
}
